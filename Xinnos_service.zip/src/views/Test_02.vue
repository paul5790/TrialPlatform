<template>
  <div>
    <h1>Test 02</h1>
  </div>
</template>

<script>
export default {
  name: 'Test02',
}
</script>

<style lang="">
  
</style>